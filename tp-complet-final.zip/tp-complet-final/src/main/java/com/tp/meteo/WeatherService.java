package com.tp.meteo;

public interface WeatherService {
    String getCurrentWeather(String city);
}
